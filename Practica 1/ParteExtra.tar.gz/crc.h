#ifndef _CRC_H_
#define _CRC_H_

#include <stddef.h>
#include <stdio.h>

unsigned int memcrc(const unsigned char *buf, size_t size);


#endif 
