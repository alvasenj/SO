#! /bin/bash
if [ -f ./mytar ] ; then
	if [ -x ./mytar ] ; then
		if [ -d ./tmp/ ] ; then
			rm -r ./tmp/
		fi 
		mkdir tmp && cd tmp
		echo "Hola Mundo!" > fich1.txt
		cksum fich1.txt > checksum1.txt
		head -n 10 /etc/passwd > fich2.txt
		cksum fich2.txt >> checksum1.txt
		head -c 1024 /dev/urandom > fich3.dat
		cksum fich3.dat >> checksum1.txt
		../mytar -c -f fichtar.mtar fich1.txt fich2.txt fich3.dat
		mkdir out
		cp fichtar.mtar ./out/ && cd out
		../../mytar -x -f fichtar.mtar
		cksum fich1.txt > checksum2.txt
		cksum fich2.txt >> checksum2.txt
		cksum fich3.dat >> checksum2.txt
		diff fich1.txt ../fich1.txt
		if [ $? = 1 ] ; then
			echo "Los ficheros fich1.txt no son iguales"
			cd ..
		fi
		diff fich2.txt ../fich2.txt
		if [ $? = 1 ] ; then
			echo "Los ficheros fich2.txt no son iguales"
			cd ..
		fi
		diff fich3.dat ../fich3.dat
		if [ $? = 1 ] ; then
			echo "Los ficheros fich3.dat no son iguales"
			cd ..
		fi
		if [ $? = 0 ] ; then
			echo "Correcto"
		fi
		diff checksum2.txt ../checksum1.txt
		if [ $? = 0 ] ; then
			echo "Checksum iguales"
		fi
		
	else 
		echo "El programa mytar no es ejecutable" 
	fi
else 
	echo "El programa mytar no está en el directorio actual"
fi
