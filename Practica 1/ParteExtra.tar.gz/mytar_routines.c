#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"
#include "crc.h"

//extern char *use;

//Copia un archivo origen a un archivo destino y devuelve el tamaño del archivo
/** Copy the nBytes origin file to destination file.
 *
 * origin: file descriptor pointer FILE of origin
 * destination:  file descriptor pointer FILE of destination
 * nBytes: number of bytes to copy
 *
 * Returns the number of bytes copied or -1 if error.
 */
int copynFile(FILE * origin, FILE * destination, int nBytes){
	// Complete the function
	int c = 0, numB = 0;

	while (numB < nBytes) {
		c = getc(origin); // c va avanzando con cada entrada en el bucle
		if (feof(origin)) break;
		putc(c, destination); // copia en el destino el caracter c
		numB++;
	}

	if (ferror(origin)) { //Comprobacion de error de fichero
		perror("Error de lectura");
		return -1;
	}

	return numB;
}


/** Loads a string from a file.
 *
 * file: file descriptor pointer to FILE structure
 * buf: address pointer that is initialized with the address where
 * the string is copied. It will be the heap address obtained with malloc.
 *
 * Returns: 0 if success, -1 if error
 */
int loadstr(FILE * file, char **buf){
	// Complete the function

	int c = 0, numB = 0;
	char *array = NULL;

	//Calculamos el numero de Bytes de file para posteriormente reservar memoria
	do {
		c = getc(file); //getc lee el nombre del archivo
		if (feof(file)) break;
		numB++;
	} while (c != '\0');
	
	if (ferror(file)) {
		perror("Error de lectura");
		return -1;
	}

	int aux;
	aux = numB - 2 * numB;
	fseek(file, aux, SEEK_CUR); //Desplazamos el indicador a la posición actual con SEEK_CUR

	//Reservamos memoria
	array = malloc(numB);
	if (array == NULL) return -1; 

	fread(array, numB-1, 1, file);

	//Devolvemos en *buf el nombre del archivo
	(*buf) = array;

	return 0;
}

/** Read tarball header and store it in memory.
 *
 * tarFile: FILE descriptor pointer of the tarball
 * header: pointer address that is initialized with the buffer address
 * that contains the descriptors of the files loaded. 
 * nFiles: integer address (integer pointer) that is initialized with #files
 * contained in the tarball (first bytes of header)
 *
 * Returs: EXIT_SUCCESS if success or EXIT_FAILURE if error
 * (macros defined in stdlib.h).
 */

int readHeader(FILE * tarFile, stHeaderEntry ** header, int *nFiles){

	int i;
	stHeaderEntry *p;

	//Leemos el número de ficheros (N) del tarFile y lo copiamos en nFiles
	fread((int *)nFiles, sizeof(int), 1, tarFile);

	/* Reservamos memoria para el array */
	p = (stHeaderEntry *) malloc(sizeof (stHeaderEntry) * (*nFiles));
	if (p == NULL) return (EXIT_FAILURE);

	//Actualizamos el indicador de posicion al inicio del fichero con SEEK_SET
	fseek(tarFile, sizeof(int), SEEK_SET);

	int result;
	char *datos;
	for (i = 0; i < *nFiles; i++) {
		datos = NULL;
		//Usamos loadstr para cargar el p[i].name (pasamos &p[i].name)
		result = loadstr(tarFile, &datos);
		if (result == -1) return (EXIT_FAILURE);
		p[i].name = datos;

		//Actualizamos el indicador de posicion del fichero
		fseek(tarFile, 1, SEEK_CUR);

		//Leemos el tamaño del fichero y lo almacenamos en p[i].size con &
		fread(&p[i].size, sizeof(int), 1, tarFile);
	}

	(*header) = p;

	return (EXIT_SUCCESS);

}


/** build a tarball with crea un tarball a partir de unos ficheros de entrada.
 *
 * nfiles:   #input files
 * filenames: array with input the files' name (paths)
 * tarname: tarball name
 * 
 * Returns EXIT_SUCCESS if success and EXIT_FAILURE if error
 * (macros defined in stdlib.h).
 *
 * HELP: fist reserve room for the tarball header,
 * jump this header size and copy one by one all files,
 * filling at the same time tallbar representation header at memory space.
 * Finally, copy tarball from memory space to header file.
 *
 * Reminder: it is not valid a simple sizeof of stHeaderEntry to
 * calculate the room needed, because sizeof not compute a string size,
 * it's only obtained the pointer size. To compute string size should be used
 * strlen function.
 */

int createTar(int nFiles, char *fileNames[], char tarName[]){
	// Complete the function
	FILE *tarFile, *inputFile;
	stHeaderEntry *header;
	int i;

	tarFile = fopen(tarName, "w"); //Crea el archivo del tarball en modo escritura
	if (tarFile == NULL) {
		perror("Error");
		return (EXIT_FAILURE);
	}
	
	header = (stHeaderEntry *) malloc(sizeof (stHeaderEntry) * (nFiles)); //Reserva memoria
	if (header == NULL) return (EXIT_FAILURE);
	
	
	int acum = sizeof(int); //Tamaño de un entero para la lectura

	//Copiamos el nombre de cada archivo en el array header y con acum calculamos donde está el final
	for (i = 0; i < nFiles; i++) {
		header[i].name = fileNames[i];
		acum += strlen(fileNames[i]) + 1 + sizeof(int);
	}

	//Situamos el indicador a partir del final de los nombres
	fseek(tarFile, acum, SEEK_SET);

	int size;

	//Abrimos cada archivo con cada nombre dado por fileNames[] y calculamos su tamaño
	for (i = 0; i < nFiles; i++) {
		inputFile = fopen(fileNames[i], "r"); //Apertura del archivo en modo lectura
		if (inputFile == NULL) {
			perror("Error");
			return (EXIT_FAILURE);
		}
		size = copynFile(inputFile, tarFile, INT_MAX); //Calculamos el tamaño del archivo
		if (size != -1) header[i].size = size;
		else return (EXIT_FAILURE);
		fclose(inputFile);
	}


	fseek(tarFile, 0, SEEK_SET);

	fwrite(&nFiles, sizeof(int), 1, tarFile); //Escribe al comienzo del fichero el numero de archivos que contiene el tarball

	char salto = '\0';

	for (i = 0; i < nFiles; i++) {	//Bucle para escribir el contenido de la cabecera en el tarFile
		fwrite(header[i].name, strlen(header[i].name), 1, tarFile);
		fwrite(&salto, 1, 1, tarFile);
		fwrite(&header[i].size, sizeof(int), 1, tarFile);
	}

	free(header);
	fclose(tarFile);

	return (EXIT_SUCCESS);


}

/** Extract all file from a tarball
 *
 * tarName: string with tarball's name
 *
 * Returns EXIT_SUCCESS if success and EXIT_FAILURE if error (macros
 * defined in stdlib.h).
 *
 * HELP: first load the header, it also means that we will place at
 * start of the first file stored. Then, extract file[s] info
 * from the header (files name and bytes to be read)
 *
 */

int extractTar(char tarName[]){
	// Complete the function
	stHeaderEntry *header;
	int nFiles, i;
	FILE *tarFile,*outputFile;

  	tarFile = fopen(tarName, "r"); //Abrimos en modo lectura el tarball
	if (tarFile == NULL) {
		perror("Error");
		return (EXIT_FAILURE);
	}
  
	//Llamo a readHeader para que me devuelva el datos, tamaño y el numero de archivos
	readHeader(tarFile, &header, &nFiles);

	int result;
	for (i = 0; i < nFiles;  i++) { //Bucle para crear los archivos extraidos del tarball
		outputFile = fopen(header[i].name , "w"); //Creamos el archivo en modo escritura
		if (outputFile == NULL) {
			perror("Error");
			return (EXIT_FAILURE);
		}
		result = copynFile(tarFile, outputFile, header[i].size); //Escribimos en el archivo sus datos correspondientes
		if (result == -1) return (EXIT_FAILURE);
		fclose(outputFile);
	}

	free(header);
	fclose(tarFile);
	
	return (EXIT_SUCCESS);
}

int computeChecksums(char tarName[]){

	stHeaderEntry *header;
	int nFiles, i;
	FILE *tarFile;

  	tarFile = fopen(tarName, "r"); //Abrimos en modo lectura el tarball
	if (tarFile == NULL) {
		perror("Error");
		return (EXIT_FAILURE);
	}
  
	//Llamo a readHeader para que me devuelva el datos, tamaño y el numero de archivos
	readHeader(tarFile, &header, &nFiles);

	unsigned char* check;
	int a;
	for (i = 0; i < nFiles;  i++) { 
		check = malloc(header[i].size);
		fread(check, header[i].size, 1, tarFile);
		a = memcrc(check, header[i].size);
		printf("%u \n", a); 
		free(check);	
	}

	free(header);
	fclose(tarFile);
	
	return (EXIT_SUCCESS);


}
